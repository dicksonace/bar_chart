<?php 

  $connect = mysqli_connect("localhost","root","","chart");




  $query = "SELECT * FROM charts ORDER BY id DESC LIMIT 5";


    $res = mysqli_query($connect,$query);

    $xvalues = array();
    $yvalues =array();
    $backcor = array();

    while ($row = mysqli_fetch_array($res)) {
    	
    	$xvalues[] = $row['xvalues'];
    	$yvalues[]  = $row['yvalues'];
    	$backcor[]  = $row['backcor'];
    }



    $data = array(
      "xvalues" => $xvalues,
      "yvalues" => $yvalues,
      "backcor" => $backcor
    );


echo json_encode($data);
   
















 ?>