<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Chart</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
</head>
<body>

	<div class="container-fluid">
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-4">
					<h1 class="text-center">Pie Chart</h1>
                     <canvas id="pie" class="col-me-12"></canvas>
				</div>
				<div class="col-md-4">
					<h1 class="text-center">Bar Chart</h1>
					<canvas id="bar" class="col-md-12"></canvas>
				</div>
				<div class="col-md-4">
					<h1 class="text-center">Add New Data</h1>

					<form id="myform">
						<input type="text" name="xvalue" class="form-control my-3">
						<input type="number" name="yvalue" class="form-control my-3">
						<input type="color" name="backcor" class="form-control my-3">
						<input type="submit" name="add" value="Add New" class="btn btn-success" id="add">
					</form>
				</div>
			</div>
		</div>
	</div>






 <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 
<script type="text/javascript">

	$(document).ready(function(){

        
        load_chart();

        function load_chart(){
           
                  
        	$.ajax({
              url: "ajax.php",
              method:"POST",
              dataType:"JSON",
              success:function(data){
                 
                 	var xValues = data.xvalues;
				var yValues = data.yvalues;
				var barColors = data.backcor;

			  new Chart("pie", {
			  type: "pie",
			  data: {
			    labels: xValues,
			    datasets: [{
			      backgroundColor: barColors,
			      data: yValues
			    }]
			  },
			  options: {
			    title: {
			      display: true,
			      text: "World Wide Wine Production 2018"
			    }
			  }
			});








              

				new Chart("bar", {
				  type: "bar",
				  data: {
				    labels: xValues,
				    datasets: [{
				      backgroundColor: barColors,
				      data: yValues
				    }]
				  },
				  options: {
				    legend: {display: false},
				    title: {
				      display: true,
				      text: "World Wine Production 2018"
				    }
				  }
				});
              }
          
			
        	});
        }





        $("#add").click(function(e){
            e.preventDefault();

            $.ajax({
               method:"POST",
               url: "addnew.php",
               data: $("#myform").serialize(),
               success:function(data){
               	load_chart();

               	 }
            });
        });
	});
</script>
</body>
</html>