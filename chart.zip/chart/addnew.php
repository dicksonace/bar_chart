<?php 

$connect = mysqli_connect("localhost","root","","chart");



$xvalue = $_POST['xvalue'];
$yvalue = $_POST['yvalue'];
$backcor = $_POST['backcor'];



$query = "INSERT INTO charts(xvalues,yvalues,backcor) VALUES('$xvalue','$yvalue','$backcor')";

$res = mysqli_query($connect,$query);


if ($res) {
	// code...
}



 ?>